//
//  main.m
//  hw2
//
//  Created by itlab on 2020/10/27.
//  Copyright © 2020 itlab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
