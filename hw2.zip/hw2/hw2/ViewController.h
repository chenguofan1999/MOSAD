//
//  ViewController.h
//  hw2
//
//  Created by itlab on 2020/10/27.
//  Copyright © 2020 itlab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

