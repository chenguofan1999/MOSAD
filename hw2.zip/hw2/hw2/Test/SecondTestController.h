//
//  SecondTestController.h
//  hw2
//
//  Created by itlab on 2020/10/28.
//  Copyright © 2020 itlab. All rights reserved.
//

#ifndef SecondTestController_h
#define SecondTestController_h

#import <UIKit/UIKit.h>


@interface SecondTestController : UIViewController
@end

#endif /* SecondTestController_h */
