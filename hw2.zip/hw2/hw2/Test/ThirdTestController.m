//
//  ThirdTestView.m
//  hw2
//
//  Created by itlab on 2020/10/28.
//  Copyright © 2020 itlab. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ThirdTestController.h"
@implementation ThirdTestController

- (void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
}

@end
