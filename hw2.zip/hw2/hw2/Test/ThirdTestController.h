//
//  ThirdTestController.h
//  hw2
//
//  Created by itlab on 2020/10/28.
//  Copyright © 2020 itlab. All rights reserved.
//

#ifndef ThirdTestController_h
#define ThirdTestController_h

#import <UIKit/UIKit.h>

@interface ThirdTestController : UIViewController
@end

#endif /* ThirdTestController_h */
