//
//  TarBarController.h
//  hw2
//
//  Created by itlab on 2020/10/27.
//  Copyright © 2020 itlab. All rights reserved.
//

#ifndef TabBarController_h
#define TabBarController_h

#import <UIKit/UIKit.h>

@interface TabBarController : UITabBarController <UITabBarDelegate>
@property (nonatomic) UIColor *color;



@end

#endif /* TarBarController_h */
