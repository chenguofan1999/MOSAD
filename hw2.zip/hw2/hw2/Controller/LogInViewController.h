//
//  LogInViewController.h
//  hw2
//
//  Created by itlab on 2020/10/28.
//  Copyright © 2020 itlab. All rights reserved.
//

#ifndef LogInViewController_h
#define LogInViewController_h
#import <UIKit/UIKit.h>

@interface LogInViewController : UIViewController

@end

#endif /* LogInViewController_h */
