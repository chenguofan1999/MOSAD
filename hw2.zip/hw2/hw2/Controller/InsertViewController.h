//
//  InsertViewController.h
//  hw2
//
//  Created by itlab on 2020/10/28.
//  Copyright © 2020 itlab. All rights reserved.
//

#ifndef InsertViewController_h
#define InsertViewController_h
#import <UIKit/UIKit.h>

@interface InsertViewController : UIViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@end

#endif /* InsertViewController_h */
