//
//  FindViewController.h
//  hw2
//
//  Created by itlab on 2020/10/28.
//  Copyright © 2020 itlab. All rights reserved.
//

#ifndef FindViewController_h
#define FindViewController_h

#import <UIKit/UIKit.h>

@interface FindViewController : UITableViewController


@end
#endif /* FindViewController_h */
